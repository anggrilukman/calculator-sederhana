package com.example.calc;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

@SuppressLint("CustomSplashScreen")
public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        ImageView splashImage = findViewById(R.id.splashImage);
        ImageView titleImage = findViewById(R.id.titleImage);
        Button enterButton = findViewById(R.id.enterButton);

        // Set up the fade-in animation for both images
        ObjectAnimator fadeInSplash = ObjectAnimator.ofFloat(splashImage, "alpha", 0f, 1f);
        fadeInSplash.setDuration(2000); // Adjust the duration as needed

        ObjectAnimator fadeInTitle = ObjectAnimator.ofFloat(titleImage, "alpha", 0f, 1f);
        fadeInTitle.setDuration(2000); // Adjust the duration as needed

        // Start the animations
        fadeInSplash.start();
        fadeInTitle.start();
        enterButton = findViewById(R.id.enterButton);
        enterButton.setOnClickListener(view -> {
            // When the "Enter" button is clicked, navigate to activity_main.xml
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            finish(); // Optional: finish the current activity
        });
    }
}
