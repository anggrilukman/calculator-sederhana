package com.example.calc;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText num1, num2;
    TextView result;
    View mainView; // View to cover the entire screen

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num1 = findViewById(R.id.num1);
        num2 = findViewById(R.id.num2);
        result = findViewById(R.id.result);

        // Initialize and set up click listener for the backToSplashButton
        Button backToSplashButton = findViewById(R.id.backToSplashButton);

        backToSplashButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Handle the button click to go back to SplashActivity
                Intent intent = new Intent(MainActivity.this, SplashActivity.class);
                startActivity(intent);
                finish(); // Optional, depending on your navigation requirements
            }
        });

        // Get the main view (layout container)
        mainView = findViewById(android.R.id.content);

        // Set up touch listener for hiding the keyboard when clicking outside EditText
        mainView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                hideSoftKeyboard();
                return false;
            }
        });
    }

    // Function to hide the soft keyboard
    private void hideSoftKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(mainView.getWindowToken(), 0);
    }

    public void add(View view) {
        performOperation('+');
    }

    public void subtract(View view) {
        performOperation('-');
    }

    public void multiply(View view) {
        performOperation('*');
    }

    public void divide(View view) {
        performOperation('/');
    }

    public void reset(View view) {
        // Clear the EditText fields and result TextView
        num1.setText("");
        num2.setText("");
        result.setText("");
    }

    // New method to perform the calculation
    @SuppressLint("SetTextI18n")
    public void performOperation(char operator) {
        int number1, number2;

        try {
            number1 = Integer.parseInt(num1.getText().toString());
            number2 = Integer.parseInt(num2.getText().toString());

            switch (operator) {
                case '+':
                    result.setText(String.valueOf(number1 + number2));
                    break;
                case '-':
                    result.setText(String.valueOf(number1 - number2));
                    break;
                case '*':
                    result.setText(String.valueOf(number1 * number2));
                    break;
                case '/':
                    if (number2 == 0) {
                        result.setText("Cannot divide by zero");
                    } else {
                        result.setText(String.valueOf(number1 / number2));
                    }
                    break;
            }
        } catch (NumberFormatException e) {
            result.setText("Invalid input. Please enter valid numbers.");
        }
    }

    // Define the clearTextNum1 method
    public void clearTextNum1(View view) {
        num1.setText(""); // Clears the text in num1 EditText
    }

    // Define the clearTextNum2 method
    public void clearTextNum2(View view) {
        num2.setText(""); // Clears the text in num2 EditText
    }

    public void backToSplash(View view) {
        Intent intent = new Intent(this, SplashActivity.class);
        startActivity(intent);
        finish(); // Optional: finish the current activity
    }
}
